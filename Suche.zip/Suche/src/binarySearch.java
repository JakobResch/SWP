class BinarySearch {
	static int zaeler;
    int binarySearch(int arr[], int x)
    {
    	
        int low = 0, high = arr.length - 1;
        zaeler = 0;
        while (low <= high) {
        	zaeler +=1;
            int mid = low + (high - low) / 2;
            
            if (arr[mid] == x) {
            	System.out.println("gefunden");
            	return mid;
            }

            if (arr[mid] < x) {
            	System.out.println("groesser");
            	low = mid + 1;
            	
            }

            else {
            	System.out.println("kleiner");
            	
            	high = mid - 1;
            }
        }
        return -1;
    }

    public static void main(String args[])
    {
        BinarySearch ob = new BinarySearch();
        int arr[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 ,13, 14, 15};
        int n = arr.length;
        int x = 1;
        int position = ob.binarySearch(arr, x);
        if (position == -1)
            System.out.println("Zahl nicht im Grenzbereich (1-15)");
        else
            System.out.println("Z�hlschritte:" +zaeler );
    }
}
